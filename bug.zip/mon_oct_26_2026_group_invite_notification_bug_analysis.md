# Copilot Chat Conversation Export: Group invite notification bug analysis

**User:** @Kitaajya
**Thread URL:** https://github.com/copilot/c/f330833a-52e8-427d-b9ec-687dff587a44

## @Kitaajya

群主拉人进群，被拉者无法得知自己在群中

## Copilot

根因很明确：这是“拉人成功了，但没有给被拉者发入群通知，也没有让其前端感知到群列表变了”。

我在代码里能确认到几个关键点：

- `PrivateMessageService.addGroupMember` 只做了这一步：
  - `privateMessageMapper.addGroupMember(groupId, userId)`
  - 然后直接返回成功
- 但 `PrivateMessageMapper` 里其实已经准备好了入群通知能力：
  - `selectGroupName`
  - `countUser`
  - `insertGroupInviteNotify`
- 可问题是：`addGroupMember` 根本没有调用 `insertGroupInviteNotify(...)`
- 前端 `syncMyGroups()` 也只是“比本地缓存里群数量是否变多”，不会真正让被拉的用户收到“你已加入xx群”的提示；它只是本地轮询，不是通知

对应代码逻辑可以概括成：

- 目标用户被插入 `group_member`
- 但没有插入 `notification`（`type='group_invite'`）
- 也没有在前端触发“你已被拉进群”的 toast
- 所以被拉者打开消息页时，如果没有手动刷新/轮询到新群，几乎看不出自己在群里

另外，这个注释也直接写了当前 bug：

- `PrivateMessageService` 顶部有注释：
  - “仍有bug未被修复：群主拉人进群，被拉者无法得知自己在群中，且群众有人发消息时，其余人也无法获取红点通知”

再看前端，`setGroupUnread()` 这种本地红点逻辑只在当前页面和本地存储里更新，实际并没有服务端真正统计“这个用户在某个群里哪些消息没看”，所以群消息红点也会失灵。

最直接的修复方式是：

1. 后端在 `addGroupMember` 里补上：
   - 校验用户存在
   - 插入 `group_member`
   - 查询群名
   - 给被拉用户写一条 `notification`：`type='group_invite'`
   - `ref_id = groupId`
   - `contents = "你已被加入群聊：xxx"`

例如思路：

```java
public Result<Map<String,Object>> addGroupMember(String groupId, String userId, String fromUser){
    if (userId == null || userId.isBlank()) return Result.fail("用户不得为空！");
    if (privateMessageMapper.countUser(userId) == 0) return Result.fail("用户不存在！");
    int k = privateMessageMapper.addGroupMember(groupId, userId);
    if (k == 0) return Result.fail("拉人失败！重新拉人！");

    String groupName = privateMessageMapper.selectGroupName(groupId);
    String notifyId = new RandomlyCreateID().createId();
    privateMessageMapper.insertGroupInviteNotify(
        notifyId, userId, fromUser, groupId, "你已被加入群聊：" + groupName
    );

    return Result.success("成功！", Map.of("userId", userId));
}
```

2. 前端在 `syncMyGroups()` 里不要只比数量，要：
   - 对比本地缓存和服务端返回的 `groupId`
   - 如果新出现了某个 `groupId`，就提示 `你已被拉入新的群聊！`
   - 同时把该群加入本地 `groupKey`

3. 群消息红点：
   - 需要增加真正的“群未读”统计字段或 `group_read` 表
   - 不是只靠前端 localStorage 乱写
   - 例如每个用户对每个群维护 `last_read_time`
   - 发送群消息时统计 `create_time > last_read_time` 的消息数

结论：
这不是“拉人失败”，而是“拉人成功，但没有通知被拉者，也没有真正同步群列表/未读状态”。这是当前仓库里这类 bug 的根因。

## @Kitaajya

那前端怎么写

## Copilot

前端核心就是：不要再用“群数量增加”来判断“被拉进群”，而要用“群 ID 集合变化”来判断，并在新群出现时弹提示、自动打开、刷新本地缓存。

你这个仓库里的问题就在 `src/main/resources/static/js/message.js` 这段：

```js
// 错误写法
if (lastGroupCount !== -1 && myGroups.length > lastGroupCount) {
    YT.toast('🔔 你已被拉入新的群聊！');
}
lastGroupCount = myGroups.length;
```

这个逻辑只看数量，不能区分“自己有新群”“只是列表顺序变了”“群被删了又增了”，而且如果你开了本地缓存，很多时候根本不会触发。

正确写法如下：

```js
// 在 message.js 里新增
const groupIdKey = 'yt_group_ids_' + me.userId;

function getStoredGroupIds() {
    try {
        return JSON.parse(localStorage.getItem(groupIdKey) || '[]');
    } catch {
        return [];
    }
}

function setStoredGroupIds(ids) {
    localStorage.setItem(groupIdKey, JSON.stringify(ids));
}
```

然后改 `syncMyGroups()`：

```js
async function syncMyGroups() {
    try {
        const r = await YT.api.get('/api/private_message/select/my/groups', { me: me.userId });
        if (!r || !r.data) return;

        const serverGroups = Array.isArray(r.data) ? r.data : [];
        const myGroups = serverGroups.map(g => ({
            groupId: String(YT.pick(g, 'groupId', 'group_id')),
            groupName: String(YT.pick(g, 'groupName', 'group_name')),
            ownerId: String(YT.pick(g, 'ownerId', 'owner_id')),
            createTime: String(YT.pick(g, 'createTime', 'create_time'))
        }));

        const oldIds = new Set(getStoredGroupIds());
        const newIds = myGroups.map(g => g.groupId);
        const addedIds = newIds.filter(id => !oldIds.has(id));

        // 关键：只要出现新 groupId，就说明“被拉进群了”
        if (addedIds.length > 0) {
            for (const gid of addedIds) {
                const g = myGroups.find(x => x.groupId === gid);
                if (g) {
                    YT.toast(`🔔 你已被拉入群聊：${g.groupName}！`);
                } else {
                    YT.toast('🔔 你已被拉入新的群聊！');
                }
            }
        }

        // 保存最新群列表
        setStoredGroupIds(newIds);
        setMyGroups(myGroups);
        renderMyGroups();

        // 如果当前没打开群聊，并且刚刚加入了新群，直接打开第一条新群
        if (addedIds.length > 0 && !currentGroup) {
            const firstNew = myGroups.find(g => addedIds.includes(g.groupId));
            if (firstNew) {
                openGroupChat(firstNew.groupId, firstNew.groupName);
            }
        }

    } catch (e) {
        console.error("同步群列表失败", e);
    }
}
```

这样前端的行为就是：

- 先拿后端真实的 `select/my/groups`
- 对比本地缓存里的 `groupId`
- 只要发现有新 `groupId`
- 立刻弹提示
- 更新本地 `groupKey`
- 刷新左侧群聊列表

另外，后端其实已经有 `notification.type='group_invite'` 的设计；前端也应该把通知拉取出来展示，而不是只靠群列表轮询。

可以补一个类似这样的通知加载：

```js
async function loadGroupInvites() {
    try {
        const r = await YT.api.get('/api/video/notify', { owner: me.userId });
        const rows = Array.isArray(r.data) ? r.data : [];
        const invites = rows.filter(n => String(n.type) === 'group_invite' || String(n.notifyType) === 'group_invite');

        if (invites.length) {
            for (const n of invites) {
                const groupId = YT.pick(n, 'refId', 'ref_id', 'groupId', 'group_id');
                const content = YT.pick(n, 'contents', 'content') || '你收到一条群邀请';
                YT.toast(`📩 ${content}`);
                console.log('群邀请', groupId, content);
            }
        }
    } catch (e) {
        console.error('加载群邀请通知失败', e);
    }
}
```

然后在初始化里一起调用：

```js
(async () => {
    await Promise.all([
        loadInbox(),
        refreshUnread(),
        syncMyGroups(),
        loadGroupInvites()
    ]);
    schedulePoll();
})();
```

还有一个要注意的点：你现在的 `pollOnce()` 里也在不停 `syncMyGroups()`, 但它的前提还是 “本地缓存比较” 的逻辑；只要改成 `groupId` diff，群提醒就会准确很多。

如果你愿意，我可以直接按你这个 `message.js` 结构给你一份完整可粘贴的修正版代码。

## @Kitaajya

你现在看看我改对了吗，我提交到仓库了

## Copilot

大方向是对的，但现在还差一个关键对接：后端参数和前端调用不一致，导致“拉人”接口仍然会失败。

我看到了两处关键点：

- 后端已修成了“真正写入群邀请通知”
  - `src/main/java/org/designer/youtube/service/PrivateMessageService.java`
  - 这里已经加了：
    - `countUser(userId)`
    - `addGroupMember(groupId, userId)`
    - `insertGroupInviteNotify(...)`
- 但控制器里要求传 `fromUser`，而前端没有传

对应代码：

```java name=src/main/java/org/designer/youtube/controller/PrivateMessageController.java
@PostMapping("/add/member")
public Result<Map<String, Object>> addGroupMember(@RequestParam String groupId, @RequestParam String userId,@RequestParam String fromUser) {
    return privateMessageService.addGroupMember(groupId, userId,fromUser);
}
```

而你现在前端的拉人调用还是：

```javascript name=src/main/resources/static/js/message.js
await YT.api.post('/api/private_message/add/member', {
    groupId: newGroupId,
    userId: uid
}).catch(() => {});
```

这里确实漏了 `fromUser: me.userId`。

所以现在的真实问题是：

- 后端修了通知逻辑，方向正确
- 但前端每次调 `/api/private_message/add/member` 都不带 `fromUser`
- 所以后端直接报参数缺失/请求失败
- 结果就是“你以为拉人成功了，但实际接口没真正走通”

该怎么修：

- 前端所有拉人请求统一改成：

```javascript
await YT.api.post('/api/private_message/add/member', {
    groupId: newGroupId,
    userId: uid,
    fromUser: me.userId
});
```

还有一个建议：

- 创建群时，群主自己已在 `establishGroup` 里被自动插入 `group_member`
- 拉别人时，fromUser 应该传“邀请人/群主ID”，这样通知里 `from_user` 才有来源，不会是空值

另外，你这版前端这部分是正确的：

```javascript
const oldIds = new Set(getStoredGroupIds());
const newIds = myGroups.map(g => g.groupId);
const addedIds = newIds.filter(id => !oldIds.has(id));
```

这个 `groupId` diff 判断法，是“被拉进群”的正确思路，优于之前的 `myGroups.length > lastGroupCount`。这点我认可。

所以结论是：

- 你的思路是对的
- 关键修正已经做到了后端通知插入
- 但还需要把前端 `add/member` 请求补上 `fromUser`
- 这样才能真正完成“群主拉人进群，被拉者知道自己在群里”的链路

如果你愿意，我可以直接给你一版“最小修正”代码，把这两个地方一起改完。

## @Kitaajya

你现在看看对吗

## Copilot

还不算完全对，当前代码状态是“方向对，但还没打通”。

我看了当前仓库，至少有 2 个硬伤：

- 1) Controller 和 Service 参数不一致
  - 在 src/main/java/org/designer/youtube/controller/PrivateMessageController.java 里，`addGroupMember` 已经改成了 3 个参数：
    - groupId
    - userId
    - fromUser
  - 但在 src/main/java/org/designer/youtube/service/PrivateMessageService.java 里，我看到的当前实现还是只有：
    - addGroupMember(String groupId, String userId)
  - 也就是说，Controller 调用 `privateMessageService.addGroupMember(groupId, userId, fromUser)`，但 Service 里不存在这个重载，代码会直接编译失败。

- 2) 前端仍然没有把 fromUser 传过去
  - 在 src/main/resources/static/js/message.js 里，拉人调用仍然是这种写法：
    - groupId
    - userId
  - 没有 `fromUser: me.userId`
  - 这导致后端拿不到邀请人，通知也写不完整，或者直接报参数错误。

所以目前的结论是：
- “想法/思路”是对的：用 groupId diff 判断“被拉进群”，并在后端写入 `group_invite` 通知
- 但“代码连接”还没完全接通
- 现在还不能说修复完成

你要保证的最小正确状态是：

- Controller 3 参数版本
- Service 3 参数版本
- 前端 add/member 一定带 `fromUser`
- 在 Service 里实际执行：
  - 插入 `group_member`
  - 校验 user 是否存在
  - 查询群名
  - 插入 `notification`（type=group_invite）

如果你愿意，我可以直接按你这个仓库当前结构，给你一份“最小可用修正版”代码，直接替换这 3 处：
- PrivateMessageController
- PrivateMessageService
- message.js 中的拉人调用

我可以直接给你可粘贴版本。

## @Kitaajya

给我直接可粘贴版本

## Copilot

下面是你可以直接粘贴的最小修复版，按你这个仓库现状我已经按“后端接口 + 前端调用 + 进群通知”三件事一起补齐了。

1) 替换 `src/main/java/org/designer/youtube/controller/PrivateMessageController.java`

```java
// 拉人
@PostMapping("/add/member")
public Result<Map<String, Object>> addGroupMember(@RequestParam String groupId,
                                                 @RequestParam String userId,
                                                 @RequestParam String fromUser) {
    return privateMessageService.addGroupMember(groupId, userId, fromUser);
}
```

2) 替换 `src/main/java/org/designer/youtube/service/PrivateMessageService.java`

```java
// 在原有的群里拉人
public Result<Map<String,Object>> addGroupMember(String groupId, String userId, String fromUser){
    if (groupId == null || groupId.isBlank()) return Result.fail("群号不能为空！");
    if (userId == null || userId.isBlank()) return Result.fail("用户不得为空！");
    if (fromUser == null || fromUser.isBlank()) return Result.fail("邀请人不能为空！");

    // 防脏数据：拉人前要确认用户真实存在
    if (privateMessageMapper.countUser(userId) == 0) {
        return Result.fail("用户不存在，无法拉入群聊！");
    }

    int k = privateMessageMapper.addGroupMember(groupId, userId);
    if (k == 0) return Result.fail("拉人失败！重新拉人！");

    // 发送群邀请通知给被拉用户
    String groupName = privateMessageMapper.selectGroupName(groupId);
    if (groupName == null || groupName.isBlank()) {
        groupName = "新群聊";
    }

    String notifyId = new RandomlyCreateID().createId();
    privateMessageMapper.insertGroupInviteNotify(
            notifyId,
            userId,
            fromUser,
            groupId,
            "你已被加入群聊：" + groupName
    );

    return Result.success("成功！", Map.of("userId", userId));
}

// 兼容旧调用
public Result<Map<String,Object>> addGroupMember(String groupId, String userId){
    return addGroupMember(groupId, userId, "system");
}
```

3) 替换前端 `src/main/resources/static/js/message.js` 里拉人调用

把这段：

```javascript
await YT.api.post('/api/private_message/add/member', {
    groupId: newGroupId,
    userId: uid
}).catch(() => {});
```

改成：

```javascript
await YT.api.post('/api/private_message/add/member', {
    groupId: newGroupId,
    userId: uid,
    fromUser: me.userId
}).catch(() => {});
```

同时，创建群的第二处也要改，下面这段也要同步修正：

```javascript
const addRes = await YT.api.post('/api/private_message/add/member', {
    groupId: newGroupId,
    userId: uid,
    fromUser: me.userId
});
```

4) 你这个“被拉进群”的前端提示逻辑，建议直接替换成这个版本（比 `myGroups.length > lastGroupCount` 更稳）

把你现有的 `syncMyGroups()` 改成下面这样：

```javascript
const groupIdsKey = 'yt_my_group_ids_' + me.userId;

function getStoredGroupIds() {
    try {
        return JSON.parse(localStorage.getItem(groupIdsKey) || '[]');
    } catch {
        return [];
    }
}

function setStoredGroupIds(ids) {
    localStorage.setItem(groupIdsKey, JSON.stringify(ids));
}

async function syncMyGroups() {
    try {
        const r = await YT.api.get('/api/private_message/select/my/groups', { me: me.userId });
        if (!r || !r.data) return;

        const serverGroups = Array.isArray(r.data) ? r.data : [];
        const myGroups = serverGroups.map(g => ({
            groupId: String(YT.pick(g, 'groupId', 'group_id')),
            groupName: String(YT.pick(g, 'groupName', 'group_name')),
            ownerId: String(YT.pick(g, 'ownerId', 'owner_id')),
            createTime: String(YT.pick(g, 'createTime', 'create_time'))
        }));

        const oldIds = new Set(getStoredGroupIds());
        const newIds = myGroups.map(g => g.groupId);
        const addedIds = newIds.filter(id => !oldIds.has(id));

        if (addedIds.length > 0) {
            for (const groupId of addedIds) {
                const g = myGroups.find(x => x.groupId === groupId);
                YT.toast('🔔 你已被拉入新的群聊：' + (g ? g.groupName : '群聊'));
            }
        }

        setStoredGroupIds(newIds);
        setMyGroups(myGroups);
        renderMyGroups();

    } catch (e) {
        console.error("同步群列表失败", e);
    }
}
```

这个版本的关键：
- 不再看“群数量增加”
- 而是看“有新 groupId 出现”
- 这样被拉进群才会被准确识别

如果你直接按这个改，基本就能把“群主拉人进群，被拉者无法得知自己在群中”的问题修掉。  
如果你愿意，我也可以继续给你一版“完整的 message.js 直接覆盖版”，但上面这几段已经够你直接补上去用了。

## @Kitaajya

给我完整版message.js

## Copilot

```javascript name=src/main/resources/static/js/message.js url=https://github.com/Kitaajya/Youtube_AI/blob/main/src/main/resources/static/js/message.js
/* 私信页 + 群聊（可直接覆盖版本） */
(async function () {
    const me = YT.user();
    if (!me) {
        try { sessionStorage.setItem('yt_from', 'message.html'); } catch (e) {}
        YT.toast('登录后即可使用私信');
        setTimeout(() => { location.href = 'login.html'; }, 600);
        return;
    }

    const $ = s => document.querySelector(s);
    const peersBox = $('#pm-peers'), msgs = $('#pm-msgs'), head = $('#pm-chat-head'), sideHead = $('#pm-side-head');
    const ta = $('#pm-content'), sendBtn = $('#pm-send');
    const picBtn = $('#pm-pic-btn'), videoBtn = $('#pm-video-btn');
    const picInput = $('#pm-pic-input'), videoInput = $('#pm-video-input');
    const emojiBtn = $('#pm-emoji-btn'), emojiPanel = $('#pm-emoji-panel');
    const groupsBox = $('#pm-groups');

    // ---------- 本地镜像 ----------
    const peerKey = 'yt_pm_peers_' + me.userId;
    const hiddenKey = 'yt_pm_hidden_' + me.userId;
    const groupKey = 'yt_my_groups_' + me.userId;
    const groupIdsKey = 'yt_my_group_ids_' + me.userId;

    const getPeers = () => {
        try { return JSON.parse(localStorage.getItem(peerKey) || '[]'); } catch { return []; }
    };
    const setPeers = arr => localStorage.setItem(peerKey, JSON.stringify(arr.slice(0, 100)));
    const getHidden = () => {
        try { return JSON.parse(localStorage.getItem(hiddenKey) || '[]'); } catch { return []; }
    };
    const setHidden = arr => localStorage.setItem(hiddenKey, JSON.stringify(arr));
    const getMyGroups = () => {
        try { return JSON.parse(localStorage.getItem(groupKey) || '[]'); } catch { return []; }
    };
    const setMyGroups = arr => localStorage.setItem(groupKey, JSON.stringify(arr));
    const getStoredGroupIds = () => {
        try { return JSON.parse(localStorage.getItem(groupIdsKey) || '[]'); } catch { return []; }
    };
    const setStoredGroupIds = ids => localStorage.setItem(groupIdsKey, JSON.stringify(ids));

    // ---------- 群聊辅助函数 ----------
    const getGroupReadTime = (groupId) => Number(localStorage.getItem('yt_group_read_' + me.userId + '_' + groupId) || 0);
    const setGroupReadTime = (groupId) => {
        localStorage.setItem('yt_group_read_' + me.userId + '_' + groupId, Date.now());
        localStorage.removeItem('yt_group_unread_' + me.userId + '_' + groupId);
    };
    const getGroupUnread = (groupId) => Number(localStorage.getItem('yt_group_unread_' + me.userId + '_' + groupId) || 0);
    const setGroupUnread = (groupId, count) => {
        localStorage.setItem('yt_group_unread_' + me.userId + '_' + groupId, count);
    };

    // ---------- 聊天状态 ----------
    let current = null;
    let currentGroup = null;
    let loading = false;
    let aiLock = false;
    const WITHDRAW_LIMIT_S = 120;
    let curList = [];

    function localNow() {
        const d = new Date(), p = x => String(x).padStart(2, '0');
        return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
    }

    function touchPeer(userId, name, lastMsg, lastTime, unread) {
        const arr = getPeers();
        const i = arr.findIndex(p => p.userId === userId);
        const old = i >= 0 ? arr[i] : null;
        if (i >= 0) arr.splice(i, 1);
        arr.unshift({
            userId,
            name: name || (old && old.name) || '',
            lastMsg: lastMsg !== undefined ? String(lastMsg || '') : (old && old.lastMsg) || '',
            lastTime: lastTime || (old && old.lastTime) || '',
            unread: unread !== undefined ? Number(unread) || 0 : (old && old.unread) || 0,
        });
        setPeers(arr);
        setHidden(getHidden().filter(x => x !== userId));
        renderPeers();
    }

    let withdrawRefreshTimer = null;
    function scheduleWithdrawRefresh(list) {
        if (withdrawRefreshTimer) { clearTimeout(withdrawRefreshTimer); withdrawRefreshTimer = null; }
        let next = Infinity;
        const now = Date.now();
        for (const m of list) {
            if (String(m.fromUser) !== me.userId || Number(m.isWithdrawn || 0) === 1) continue;
            const created = new Date(String(m.createTime).replace(' ', 'T')).getTime();
            if (isNaN(created)) continue;
            const end = created + WITHDRAW_LIMIT_S * 1000;
            if (end > now && end < next) next = end;
        }
        if (next === Infinity) return;
        withdrawRefreshTimer = setTimeout(() => {
            withdrawRefreshTimer = null;
            const atBottom = msgs.scrollHeight - msgs.scrollTop - msgs.clientHeight < 40;
            const keepTop = msgs.scrollTop;
            renderMsgs(curList, false);
            if (!atBottom) msgs.scrollTop = keepTop;
        }, next - now + 500);
    }

    // ---------- 渲染 UI ----------
    function renderPeers() {
        const hidden = getHidden();
        const arr = getPeers().filter(p => !hidden.includes(p.userId));
        if (!arr.length) {
            peersBox.innerHTML = '<div class="pm-empty-peers">暂无私信会话<br>收到私信后会显示在这里</div>';
            return;
        }
        peersBox.innerHTML = arr.map(p => `
            <div class="pm-peer ${current && current.userId === p.userId ? 'active' : ''}" data-peer="${YT.esc(p.userId)}">
                <span class="avatar">${YT.esc((p.name || p.userId).slice(0, 1).toUpperCase())}</span>
                <div class="p-txt">
                    <div class="p-name">${YT.esc(p.name || p.userId)}</div>
                    <div class="p-sub">${YT.esc(p.lastMsg || '（无消息）')} · ${YT.timeAgo(p.lastTime)}</div>
                </div>
                ${p.unread > 0 ? `<span class="p-badge">${p.unread > 99 ? '99+' : p.unread}</span>` : ''}
                <button class="p-del" title="从列表隐藏" data-remove="${YT.esc(p.userId)}">&#10005;</button>
            </div>`).join('');
    }

    function renderMyGroups() {
        if (!groupsBox) return;
        const arr = getMyGroups();
        if (!arr.length) {
            groupsBox.innerHTML = '';
            return;
        }
        groupsBox.innerHTML = arr.map(g => {
            const unreadCount = getGroupUnread(g.groupId);
            return `
            <div class="pm-peer ${currentGroup && currentGroup.groupId === g.groupId ? 'active' : ''}" 
                 data-group="${YT.esc(g.groupId)}" data-gname="${YT.esc(g.groupName)}" style="border-left: 3px solid var(--link);">
                <span class="avatar" style="background:var(--link);color:#fff;border-radius:8px;">群</span>
                <div class="p-txt">
                    <div class="p-name">${YT.esc(g.groupName)}</div>
                    <div class="p-sub">群号: ${YT.esc(g.groupId)}</div>
                </div>
                ${unreadCount > 0 ? `<span class="p-badge">${unreadCount > 99 ? '99+' : unreadCount}</span>` : ''}
            </div>`;
        }).join('');
    }

    function emojiSrc(fileName) {
        return 'emoji/' + encodeURIComponent(String(fileName));
    }

    function msgHtml(m, isGroup = false) {
        if (String(m.contents || '').includes('正在阅读群聊并思考')) return '';

        const mine = String(m.fromUser) === me.userId;
        const withdrawn = Number(m.isWithdrawn || 0) === 1;
        const msgId = String(m.msgId || '');
        const time = YT.fmtFull(m.createTime);
        const who = isGroup ? (m.senderName || '群友') : (mine ? '我' : (current ? (current.name || current.userId) : ''));

        let bodyHtml;
        const mtype = String(m.msgType || 'text').toLowerCase();
        const mediaFile = String(m.mediaPath || '');
        if (withdrawn) {
            bodyHtml = `<div class="bubble">${mine ? '你撤回了一条消息' : '对方撤回了一条消息'}</div>`;
        } else if (mtype === 'emoji' && mediaFile) {
            bodyHtml = `<div class="bubble emoji"><img src="${emojiSrc(mediaFile)}" alt="" loading="lazy"></div>`;
        } else if (mtype === 'image' && mediaFile) {
            bodyHtml = `<div class="bubble media"><img src="${YT.mediaUrl(mediaFile)}" alt="" loading="lazy"></div>`;
        } else if (mtype === 'video' && mediaFile) {
            bodyHtml = `<div class="bubble media"><video controls preload="metadata" playsinline src="${YT.mediaUrl(mediaFile)}"></video></div>`;
        } else {
            bodyHtml = `<div class="bubble">${YT.esc(String(m.contents || ''))}</div>`;
        }

        let ops = '';
        if (mine && !isGroup && !withdrawn) {
            const created = new Date(String(m.createTime).replace(' ', 'T')).getTime();
            const fresh = !isNaN(created) && (Date.now() - created) / 1000 <= WITHDRAW_LIMIT_S;
            ops = '<div class="m-ops">'
                + (fresh ? `<button class="m-op" data-withdraw="${YT.esc(msgId)}">撤回</button>` : '')
                + `<button class="m-op" data-del="${YT.esc(msgId)}">删除</button>`
                + '</div>';
        }

        if (isGroup) {
            const avatarHtml = `<div class="pm-group-avatar" onclick="location.href='profile.html?userId=${YT.esc(m.fromUser)}&name=${encodeURIComponent(who)}'" title="查看 ${YT.esc(who)} 的资料">
                <span class="avatar">${YT.esc(who.slice(0, 1).toUpperCase())}</span>
            </div>`;
            return `
            <div class="pm-group-msg-wrap ${mine ? 'me' : ''}" data-msg-id="${YT.esc(msgId)}">
                ${avatarHtml}
                <div class="pm-group-msg-body">
                    <span class="pm-group-name">${YT.esc(who)}</span>
                    <div class="pm-msg ${mine ? 'me' : ''}">
                        ${bodyHtml}
                    </div>
                </div>
            </div>`;
        }

        return `
            <div class="pm-msg ${mine ? 'me' : ''}" data-msg-id="${YT.esc(msgId)}">
                ${bodyHtml}
                <span class="m-time">${YT.esc(who)} · ${YT.esc(time)}</span>
                ${ops}
            </div>`;
    }

    function renderMsgs(list, isGroup = false) {
        curList = list;
        if (!list.length) {
            msgs.innerHTML = '<div class="empty">还没有消息，发第一条吧</div>';
            return;
        }
        let html = '', lastMsgTime = 0;
        for (const m of list) {
            let currentMsgTime = new Date(String(m.createTime || '').replace(' ', 'T')).getTime();
            if (isNaN(currentMsgTime)) currentMsgTime = Date.now();

            if (lastMsgTime === 0 || (currentMsgTime - lastMsgTime) > 5 * 60 * 1000) {
                const d = new Date(currentMsgTime);
                const timeStr = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
                html += `<div class="pm-day">${timeStr}</div>`;
            }
            html += msgHtml(m, isGroup);
            lastMsgTime = currentMsgTime;
        }
        msgs.innerHTML = html;
        msgs.scrollTop = msgs.scrollHeight;
        if (!isGroup) scheduleWithdrawRefresh(list);
    }

    function appendMsgs(newMsgs, isGroup = false) {
        if (!newMsgs || !newMsgs.length) return;
        let html = '';
        for (const m of newMsgs) {
            html += msgHtml(m, isGroup);
        }
        msgs.insertAdjacentHTML('beforeend', html);
        msgs.scrollTop = msgs.scrollHeight;
    }

    function renderHead() {
        if (currentGroup) {
            head.innerHTML = `
                <span class="avatar" style="background:var(--link);color:#fff;border-radius:8px;">群</span>
                <b>${YT.esc(currentGroup.groupName)}</b>
                <span class="w-stats">群号: ${YT.esc(currentGroup.groupId)}</span>`;
            return;
        }
        if (!current) {
            head.textContent = '选择左侧会话开始聊天';
            return;
        }
        head.innerHTML = `
            <span class="avatar">${YT.esc((current.name || current.userId).slice(0, 1).toUpperCase())}</span>
            <b>${YT.esc(current.name || '对方')}</b>
            <span class="w-stats">ID: ${YT.esc(current.userId)}</span>`;
    }

    function previewOf(m) {
        if (Number(m.isWithdrawn || 0) === 1) return '[已撤回]';
        const t = String(m.msgType || 'text').toLowerCase();
        if (t === 'image') return '[图片]';
        if (t === 'video') return '[视频]';
        if (t === 'emoji') return '[表情]';
        return String(m.contents || '').slice(0, 30);
    }

    // ---------- 服务器通信与轮询 ----------
    const POLL_MS = 1000;
    let pollTimer = null, pollBusy = false;
    let lastInboxSig = '', lastChatSig = '', lastUnread = -1;
    let lastGroupChatSig = '';

    function inboxSig(rows) {
        return rows.map(r => [
            YT.pick(r, 'peerId', 'peer_id'), YT.pick(r, 'unread'),
            YT.pick(r, 'lastTime', 'last_time'), YT.pick(r, 'lastMsg', 'last_msg'),
        ].join('|')).join(';');
    }

    function chatSig(list) {
        const last = list[list.length - 1];
        return list.length + '|' + (last ? (last.msgId || last.createTime) : '');
    }

    function applyInboxRows(rows) {
        const server = rows.map(row => ({
            userId: String(YT.pick(row, 'peerId', 'peer_id') || ''),
            name: String(YT.pick(row, 'peerName', 'peer_name') || ''),
            lastMsg: String(YT.pick(row, 'lastMsg', 'last_msg') || '').slice(0, 30),
            lastTime: String(YT.pick(row, 'lastTime', 'last_time') || ''),
            unread: Number(YT.pick(row, 'unread') || 0),
        })).filter(p => p.userId);

        const local = getPeers();
        const merged = server.map(p => {
            const old = local.find(x => x.userId === p.userId);
            const note = old && old.name ? old.name : '';
            return { ...p, name: note || p.name };
        });
        const extra = local.filter(x => !server.some(p => p.userId === x.userId));
        setPeers([...extra, ...merged]);
        setHidden(getHidden().filter(id => {
            const p = merged.find(x => x.userId === id);
            return !(p && p.unread > 0);
        }));
        renderPeers();
    }

    async function loadInbox() {
        try {
            const r = await YT.api.get('/api/private_message/select/inbox', { me: me.userId });
            const rows = Array.isArray(r.data) ? r.data : [];
            lastInboxSig = inboxSig(rows);
            applyInboxRows(rows);
        } catch (e) { renderPeers(); }
    }

    async function syncMyGroups() {
        try {
            const r = await YT.api.get('/api/private_message/select/my/groups', { me: me.userId });
            if (!r || !r.data) return;

            const serverGroups = Array.isArray(r.data) ? r.data : [];
            const myGroups = serverGroups.map(g => ({
                groupId: String(YT.pick(g, 'groupId', 'group_id')),
                groupName: String(YT.pick(g, 'groupName', 'group_name')),
                ownerId: String(YT.pick(g, 'ownerId', 'owner_id')),
                createTime: String(YT.pick(g, 'createTime', 'create_time'))
            }));

            // 关键修复：以 groupId 差异判断是否被拉进群，不再用纯数量判断
            const oldIds = new Set(getStoredGroupIds());
            const newIds = myGroups.map(g => g.groupId);
            const addedIds = newIds.filter(id => !oldIds.has(id));

            if (addedIds.length > 0) {
                for (const gid of addedIds) {
                    const g = myGroups.find(x => x.groupId === gid);
                    YT.toast('🔔 你已被拉入新的群聊：' + (g ? g.groupName : '群聊'));
                }
            }

            setStoredGroupIds(newIds);
            setMyGroups(myGroups);
            renderMyGroups();

            if (addedIds.length > 0 && !currentGroup) {
                const firstNew = myGroups.find(g => addedIds.includes(g.groupId));
                if (firstNew) {
                    openGroupChat(firstNew.groupId, firstNew.groupName);
                }
            }

        } catch (e) {
            console.error("同步群列表失败", e);
        }
    }

    async function refreshUnread() {
        if (!sideHead) return;
        try {
            const r = await YT.api.get('/api/private_message/count/unread', { me: me.userId });
            const n = Number((r.data && r.data.count) || 0);
            if (n === lastUnread) return;
            lastUnread = n;
            let titleSpan = sideHead.querySelector('span');
            if (titleSpan) { titleSpan.textContent = n > 0 ? `私信 · 未读 ${n}` : '私信'; }
        } catch (e) { }
    }

    async function openChat(userId, name) {
        if (!userId || userId.length !== 13) { YT.toast('用户ID应为13位'); return; }
        if (userId === me.userId) { YT.toast('不能和自己聊天'); return; }

        currentGroup = null;
        ta.disabled = false;
        ta.placeholder = '写私信…（Enter 发送，Shift+Enter 换行）';
        sendBtn.disabled = false;
        emojiBtn.disabled = false;
        picBtn.disabled = false;
        videoBtn.disabled = false;

        current = { userId, name: name || '' };
        renderHead(); renderPeers(); renderMyGroups();

        msgs.innerHTML = '<div class="empty">加载对话…</div>';
        loading = true;
        try {
            const r = await YT.api.get('/api/private_message/select/message', { a: me.userId, b: userId });
            const list = Array.isArray(r.data) ? r.data : [];
            curList = list;
            lastChatSig = chatSig(list);

            const last = list[list.length - 1];
            touchPeer(userId, name, last ? previewOf(last) : undefined, last ? last.createTime : '', 0);

            msgs.innerHTML = '';
            if (!list.length) msgs.innerHTML = '<div class="empty">还没有消息，发第一条吧</div>';
            else appendMsgs(list, false);

            try { await YT.api.post('/api/private_message/read', { me: me.userId, other: userId }); } catch (e) { }
            refreshUnread();
        } catch (e) { msgs.innerHTML = `<div class="empty">加载失败：${YT.esc(e.message)}</div>`; } finally { loading = false; }
    }

    async function openGroupChat(groupId, groupName) {
        current = null;
        currentGroup = { groupId, groupName };
        ta.disabled = false;
        ta.placeholder = '发送群消息…（Enter 发送）';
        sendBtn.disabled = false;
        emojiBtn.disabled = false;
        picBtn.disabled = false;
        videoBtn.disabled = false;
        toggleEmojiPanel(true);
        renderHead(); renderPeers(); renderMyGroups();

        msgs.innerHTML = '<div class="empty">加载群聊消息…</div>';
        try {
            const r = await YT.api.get('/api/private_message/select/group/message', { groupId });
            const list = Array.isArray(r.data) ? r.data : [];
            const normList = list.map(m => ({
                msgId: YT.pick(m, 'msg_id'),
                fromUser: YT.pick(m, 'from_user'),
                toUser: groupId,
                contents: YT.pick(m, 'contents'),
                msgType: YT.pick(m, 'msg_type') || 'text',
                mediaPath: YT.pick(m, 'media_path'),
                createTime: YT.pick(m, 'create_time'),
                senderName: YT.pick(m, 'senderName', 'sender_name') || (YT.pick(m, 'from_user') === 'AI_BOT' ? 'DeepSeek 助手' : '群友')
            }));

            curList = normList;
            setGroupReadTime(groupId);
            renderMyGroups();

            msgs.innerHTML = '';
            if (!normList.length) msgs.innerHTML = '';
            else appendMsgs(normList, true);

            lastGroupChatSig = chatSig(normList);
        } catch (e) {
            msgs.innerHTML = `<div class="empty">群聊加载失败：${YT.esc(e.message)}</div>`;
        }
    }

    // ---------- 表情包 ----------
    let emojiCache = null, emojiLoading = false;
    async function loadEmojiPanel() {
        if (emojiLoading) return;
        if (!emojiCache) {
            emojiLoading = true;
            try {
                const r = await YT.api.get('/api/private_message/emoji/list');
                emojiCache = Array.isArray(r.data) ? r.data : [];
            } catch (e) {
                emojiPanel.innerHTML = '<div class="pm-empty-emoji">表情加载失败，点击重试</div>';
                emojiLoading = false;
                return;
            }
            emojiLoading = false;
        }
        if (!emojiCache.length) {
            emojiPanel.innerHTML = '<div class="pm-empty-emoji">暂无可用表情</div>';
            return;
        }
        const cells = emojiCache.map(e => ({
            file: String(YT.pick(e, 'fileName', 'file_name') || ''),
            name: String(YT.pick(e, 'name') || '')
        })).filter(it => it.file).map(it => `
            <button class="pm-emoji" data-emoji="${YT.esc(it.file)}" title="${YT.esc(it.name || it.file)}">
                <img src="${emojiSrc(it.file)}" alt="${YT.esc(it.name || it.file)}" loading="lazy">
            </button>
        `).join('');
        emojiPanel.innerHTML = `<div class="pm-emoji-cells">${cells}</div>`;
    }

    function toggleEmojiPanel(forceHide) {
        const show = !forceHide && emojiPanel.hidden;
        emojiPanel.hidden = !show;
        emojiBtn.classList.toggle('on', show);
        if (show) loadEmojiPanel();
    }

    // ---------- 媒体发送 ----------
    async function sendMedia(file) {
        if (!file) return;
        if (loading) return;

        loading = true;
        try {
            const form = new FormData();
            form.append('file', file);

            const r = await YT.api.post('/api/private_message/upload/media', form, true);
            if (!r || !r.success || !r.data || !r.data.mediaPath) {
                YT.toast(r && r.message ? r.message : '上传失败');
                return;
            }

            const mediaPath = r.data.mediaPath;
            const target = currentGroup ? { groupId: currentGroup.groupId, fromUser: me.userId, contents: '', msgType: 'image', mediaPath } : { fromUser: me.userId, toUser: current.userId, msgType: 'image', mediaPath };

            const res = await YT.api.post(
                currentGroup ? '/api/private_message/add/group/message' : '/api/private_message/send/picture/video',
                currentGroup ? target : { ...target, contents: '' }
            );

            if (!res.success) {
                YT.toast(res.message || '发送失败');
                return;
            }

            const nowMsg = {
                msgId: String((res.data && res.data.msgId) || YT.randId()),
                fromUser: me.userId,
                toUser: currentGroup ? currentGroup.groupId : current.userId,
                contents: '',
                msgType: 'image',
                mediaPath,
                createTime: localNow(),
                senderName: me.nickname || me.userId
            };

            curList.push(nowMsg);
            appendMsgs([nowMsg], !!currentGroup);

            if (currentGroup) {
                setGroupReadTime(currentGroup.groupId);
                renderMyGroups();
            } else {
                touchPeer(current.userId, current.name, previewOf(nowMsg), nowMsg.createTime);
                loadInbox();
            }

        } catch (e) {
            YT.toast('发送失败：' + e.message);
        } finally {
            loading = false;
            ta.focus();
        }
    }

    async function doSendEmoji(fileName) {
        if (!current && !currentGroup) { YT.toast('请先选择聊天对象或群聊'); return; }
        if (loading) return;
        loading = true; emojiBtn.disabled = true;
        try {
            let r;
            if (currentGroup) {
                r = await YT.api.post('/api/private_message/add/group/message', {
                    groupId: currentGroup.groupId,
                    fromUser: me.userId,
                    contents: '',
                    msgType: 'emoji',
                    mediaPath: fileName
                });
            } else {
                r = await YT.api.post('/api/private_message/send/emoji', {
                    fromUser: me.userId,
                    toUser: current.userId,
                    mediaPath: fileName
                });
            }
            if (!r.success) { YT.toast(r.message || '发送失败'); return; }

            toggleEmojiPanel(true);

            const nowMsg = {
                msgId: String((r.data && r.data.msgId) || ''),
                fromUser: me.userId,
                toUser: currentGroup ? currentGroup.groupId : current.userId,
                contents: '',
                msgType: 'emoji',
                mediaPath: fileName,
                createTime: localNow(),
                senderName: me.nickname || me.userId
            };

            curList.push(nowMsg);
            appendMsgs([nowMsg], !!currentGroup);

            if (currentGroup) {
                setGroupReadTime(currentGroup.groupId);
                renderMyGroups();
            } else {
                scheduleWithdrawRefresh(curList);
                touchPeer(current.userId, current.name, previewOf(nowMsg), nowMsg.createTime);
                loadInbox();
            }
        } catch (e) {
            YT.toast('发送失败：' + e.message);
        } finally {
            loading = false;
            emojiBtn.disabled = false;
            ta.focus();
        }
    }

    async function doSend() {
        if (currentGroup) {
            const content = ta.value.trim();
            if (!content) { YT.toast('消息不能为空'); return; }
            if (loading) return;

            sendBtn.disabled = true; loading = true;
            try {
                const r = await YT.api.post('/api/private_message/add/group/message', {
                    groupId: currentGroup.groupId,
                    fromUser: me.userId,
                    contents: content,
                    msgType: 'text'
                });
                if (!r.success) { YT.toast(r.message || '发送失败'); return; }

                ta.value = '';
                const nowMsg = {
                    msgId: String((r.data && r.data.msgId) || ''),
                    fromUser: me.userId,
                    toUser: currentGroup.groupId,
                    contents: content,
                    msgType: 'text',
                    createTime: localNow(),
                    senderName: me.nickname || me.userId
                };

                curList.push(nowMsg);
                appendMsgs([nowMsg], true);
                setGroupReadTime(currentGroup.groupId);
                renderMyGroups();

                if (content.includes('问问DeepSeek') || content.includes('问问AI') ||
                    content.includes('问问人工智能') || content.includes('DeepSeek') || content.includes('deepseek')) {
                    if (!document.getElementById('typing-ai-bubble')) {
                        aiLock = true;
                        const thinkingMsgId = YT.randId();

                        msgs.insertAdjacentHTML('beforeend', `
                        <div class="pm-group-msg-wrap" id="typing-ai-bubble">
                            <div class="pm-group-avatar"><span class="avatar" style="background:#3ea6ff; color:#fff;">AI</span></div>
                            <div class="pm-group-msg-body">
                                <span class="pm-group-name">DeepSeek 助手</span>
                                <div class="pm-msg"><div class="bubble" style="background:var(--surface-2); border: 1px dashed var(--link); color:var(--text-primary);" id="typing-ai-bubble-content">正在阅读群聊并思考...</div></div>
                            </div>
                        </div>`);
                        msgs.scrollTop = msgs.scrollHeight;

                        YT.api.post('/api/private_message/add/group/message', {
                            msgId: thinkingMsgId,
                            groupId: currentGroup.groupId,
                            fromUser: 'AI_BOT',
                            contents: '正在阅读群聊并思考...',
                            msgType: 'text'
                        }).then(() => {
                            triggerGroupAi(nowMsg, thinkingMsgId);
                        });
                    }
                }
            } catch (e) { YT.toast('发送失败：' + e.message); } finally { loading = false; sendBtn.disabled = false; ta.focus(); }
            return;
        }

        if (!current) { YT.toast('请先选择聊天对象'); return; }
        const content = ta.value.trim();
        if (!content) { YT.toast('消息不能为空'); return; }
        if (loading) return;

        sendBtn.disabled = true; loading = true;
        try {
            const r = await YT.api.post('/api/private_message/send', { fromUser: me.userId, toUser: current.userId, contents: content });
            if (!r.success) { YT.toast(r.message || '发送失败'); return; }
            ta.value = '';
            const sentMsgId = String((r.data && r.data.msgId) || '');
            const nowMsg = { msgId: sentMsgId, fromUser: me.userId, toUser: current.userId, contents: content, createTime: localNow() };
            curList.push(nowMsg);
            appendMsgs([nowMsg], false);
            touchPeer(current.userId, current.name, content.slice(0, 30), nowMsg.createTime);
            loadInbox();
        } catch (e) { YT.toast('发送失败：' + e.message); } finally { loading = false; sendBtn.disabled = false; ta.focus(); }
    }

    // ---------- 撤回 / 删除 ----------
    async function doWithdraw(msgId, node) {
        try {
            const r = await YT.api.post('/api/private_message/withdraw/private/message', {
                msgId,
                userId: me.userId,
                timeWithdraw: WITHDRAW_LIMIT_S
            });
            if (!r.success) { YT.toast(r.message || '撤回失败'); return; }

            const idx = curList.findIndex(x => String(x.msgId) === String(msgId));
            if (idx >= 0) curList[idx].isWithdrawn = 1;
            if (node) {
                const bubble = node.querySelector('.bubble');
                if (bubble) bubble.innerHTML = '<span style=\"opacity:.8;\">消息已撤回</span>';
            }
            renderMsgs(curList, !!currentGroup);
        } catch (e) {
            YT.toast('撤回失败：' + e.message);
        }
    }

    async function doDeleteFromMySide(msgId, node) {
        try {
            const r = await YT.api.post('/api/private_message/delete/private/message', {
                msgId,
                userId: me.userId
            });
            if (!r.success) { YT.toast(r.message || '删除失败'); return; }

            const idx = curList.findIndex(x => String(x.msgId) === String(msgId));
            if (idx >= 0) curList.splice(idx, 1);
            if (node) node.remove();
            if (!curList.length) {
                msgs.innerHTML = '<div class="empty">还没有消息，发第一条吧</div>';
            }
        } catch (e) {
            YT.toast('删除失败：' + e.message);
        }
    }

    // ---------- AI 自动回复 ----------
    const processedAiMsgIds = new Set();

    async function triggerGroupAi(triggerMsg, thinkingMsgId) {
        if (processedAiMsgIds.has(triggerMsg.msgId)) return;
        processedAiMsgIds.add(triggerMsg.msgId);
        aiLock = true;

        const question = `${triggerMsg.senderName} 说：“${triggerMsg.contents}”。请给出你的回答。`;
        let bubble = document.getElementById('typing-ai-bubble-content');
        let fullText = '';

        try {
            const response = await fetch(`/api/private_message/select/group/message/deepseek?groupId=${currentGroup.groupId}&question=${encodeURIComponent(question)}`);
            if (!response.ok) throw new Error('网络请求失败');

            const reader = response.body.getReader();
            const decoder = new TextDecoder('utf-8');
            let isFirstChunk = true;

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                const chunk = decoder.decode(value, { stream: true });
                if (isFirstChunk) {
                    if (bubble) bubble.innerText = '';
                    isFirstChunk = false;
                }
                fullText += chunk;
                if (bubble) bubble.innerText = fullText;
                msgs.scrollTop = msgs.scrollHeight;
            }

            if (fullText.trim()) {
                const aiReplyMsgId = YT.randId();

                const r = await YT.api.post('/api/private_message/add/group/message', {
                    msgId: aiReplyMsgId,
                    groupId: currentGroup.groupId,
                    fromUser: 'AI_BOT',
                    contents: fullText.trim(),
                    msgType: 'text'
                });

                if (r.success) {
                    const tempNode = document.getElementById('typing-ai-bubble');
                    if (tempNode) tempNode.remove();

                    if (thinkingMsgId) {
                        YT.api.post('/api/private_message/delete/private/message', { msgId: thinkingMsgId, userId: me.userId }).catch(() => {});
                    }

                    const aiMsg = {
                        msgId: aiReplyMsgId,
                        fromUser: 'AI_BOT',
                        toUser: currentGroup.groupId,
                        contents: fullText.trim(),
                        msgType: 'text',
                        createTime: localNow(),
                        senderName: 'DeepSeek 助手'
                    };

                    curList = curList.filter(m => m.msgId !== thinkingMsgId);
                    curList = curList.filter(m => m.msgId !== aiReplyMsgId);
                    curList.push(aiMsg);

                    appendMsgs([aiMsg], true);
                    lastGroupChatSig = chatSig(curList);
                } else {
                    YT.toast('AI 消息入库失败: ' + (r.message || '未知错误'));
                }
            }
        } catch (e) {
            console.error('AI 回复出错', e);
            if (bubble) bubble.innerText = 'AI 出错了：' + e.message;
        } finally {
            aiLock = false;
            const ghost = document.getElementById('typing-ai-bubble');
            if (ghost) ghost.remove();
        }
    }

    // ---------- 轮询 ----------
    async function pollOnce() {
        if (loading || aiLock) return;

        syncMyGroups();

        if (currentGroup) {
            try {
                const peerId = currentGroup.groupId;
                const r = await YT.api.get('/api/private_message/select/group/message', { groupId: peerId });
                const list = Array.isArray(r.data) ? r.data : [];
                const normList = list.map(m => ({
                    msgId: YT.pick(m, 'msg_id'), fromUser: YT.pick(m, 'from_user'), toUser: peerId,
                    contents: YT.pick(m, 'contents'), msgType: YT.pick(m, 'msg_type') || 'text',
                    mediaPath: YT.pick(m, 'media_path'), createTime: YT.pick(m, 'create_time'),
                    senderName: YT.pick(m, 'senderName', 'sender_name') || (YT.pick(m, 'from_user') === 'AI_BOT' ? 'DeepSeek 助手' : '群友')
                }));

                const sig = normList.length + '|' + (normList.length ? normList[normList.length - 1].msgId : '');

                if (sig !== lastGroupChatSig) {
                    const existingIds = new Set(curList.map(x => x.msgId));
                    const newMsgs = normList.filter(m => !existingIds.has(m.msgId));

                    if (newMsgs.length > 0) {
                        newMsgs.forEach(m => {
                            if (String(m.fromUser) === 'AI_BOT' && String(m.contents).includes('正在阅读群聊并思考')) {
                                if (!document.getElementById('typing-ai-bubble')) {
                                    msgs.insertAdjacentHTML('beforeend', `
                                    <div class="pm-group-msg-wrap" id="typing-ai-bubble">
                                        <div class="pm-group-avatar"><span class="avatar" style="background:#3ea6ff; color:#fff;">AI</span></div>
                                        <div class="pm-group-msg-body">
                                            <span class="pm-group-name">DeepSeek 助手</span>
                                            <div class="pm-msg"><div class="bubble" style="background:var(--surface-2); border: 1px dashed var(--link); color:var(--text-primary);" id="typing-ai-bubble-content">正在阅读群聊并思考...</div></div>
                                        </div>
                                    </div>`);
                                    msgs.scrollTop = msgs.scrollHeight;
                                }
                            } else {
                                appendMsgs([m], true);
                            }
                        });

                        curList.push(...newMsgs);
                    }

                    lastGroupChatSig = sig;
                    setGroupReadTime(peerId);
                    renderMyGroups();

                    const lastMsg = normList[normList.length - 1];
                    if (lastMsg && String(lastMsg.fromUser) === 'AI_BOT' && !String(lastMsg.contents).includes('正在阅读群聊并思考')) {
                        const ghost = document.getElementById('typing-ai-bubble');
                        if (ghost) ghost.remove();
                        if (aiLock) aiLock = false;
                    }
                }
            } catch (e) { console.error("群聊轮询失败", e); }
            return;
        }

        const peerId = current ? current.userId : null;
        if (!peerId) return;

        const [inboxR, unreadR, chatR] = await Promise.all([
            YT.api.get('/api/private_message/select/inbox', { me: me.userId }).catch(() => null),
            YT.api.get('/api/private_message/count/unread', { me: me.userId }).catch(() => null),
            YT.api.get('/api/private_message/select/message', { a: me.userId, b: peerId }).catch(() => null),
        ]);

        if (chatR) {
            const list = Array.isArray(chatR.data) ? chatR.data : [];
            const sig = list.length + '|' + (list.length ? (list[list.length - 1].msg_id || list[list.length - 1].msgId) : '');
            if (sig !== lastChatSig) {
                const existingIds = new Set(curList.map(x => String(x.msgId)));
                const newMsgs = list.filter(m => !existingIds.has(String(YT.pick(m, 'msg_id', 'msgId'))));
                if (newMsgs.length > 0) {
                    appendMsgs(newMsgs, false);
                    curList.push(...newMsgs);
                }
                lastChatSig = sig;
                try { await YT.api.post('/api/private_message/read', { me: me.userId, other: peerId }); } catch (e) { }
            }
        }

        if (inboxR) {
            const rows = Array.isArray(inboxR.data) ? inboxR.data : [];
            const sig = inboxSig(rows);
            if (sig !== lastInboxSig) {
                lastInboxSig = sig;
                applyInboxRows(rows);
            }
        }

        if (unreadR) {
            const n = Number((unreadR.data && unreadR.data.count) || 0);
            if (n !== lastUnread) {
                lastUnread = n;
                if (sideHead) {
                    const titleSpan = sideHead.querySelector('span');
                    if (titleSpan) titleSpan.textContent = n > 0 ? `私信 · 未读 ${n}` : '私信';
                }
            }
        }
    }

    function schedulePoll() {
        if (document.hidden) { pollTimer = null; return; }
        pollTimer = setTimeout(async () => {
            if (!pollBusy && !document.hidden) {
                pollBusy = true; try { await pollOnce(); } catch (e) {} finally { pollBusy = false; }
            }
            schedulePoll();
        }, POLL_MS);
    }

    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            if (pollTimer) { clearTimeout(pollTimer); pollTimer = null; }
        } else if (!pollTimer) {
            pollOnce().catch(() => {});
            schedulePoll();
        }
    });

    // ---------- 事件绑定 ----------
    msgs.addEventListener('click', e => {
        const w = e.target.closest('[data-withdraw]');
        if (w) { doWithdraw(w.dataset.withdraw, w.closest('.pm-msg')); return; }
        const d = e.target.closest('[data-del]');
        if (d) { doDeleteFromMySide(d.dataset.del, d.closest('.pm-msg')); }
    });

    ta.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSend(); }
    });
    sendBtn.addEventListener('click', doSend);

    picBtn.addEventListener('click', () => { picInput.value = ''; picInput.click(); });
    videoBtn.addEventListener('click', () => { videoInput.value = ''; videoInput.click(); });

    picInput.addEventListener('change', () => {
        const f = picInput.files[0];
        picInput.value = '';
        if (f) sendMedia(f);
    });
    videoInput.addEventListener('change', () => {
        const f = videoInput.files[0];
        videoInput.value = '';
        if (f) sendMedia(f);
    });

    emojiBtn.addEventListener('click', () => { toggleEmojiPanel(); });
    emojiPanel.addEventListener('click', e => {
        if (e.target.closest('.pm-empty-emoji')) { loadEmojiPanel(); return; }
        const cell = e.target.closest('[data-emoji]');
        if (cell) doSendEmoji(cell.dataset.emoji);
    });

    document.addEventListener('click', e => {
        if (emojiPanel.hidden) return;
        if (!emojiPanel.contains(e.target) && !emojiBtn.contains(e.target)) toggleEmojiPanel(true);
    });

    peersBox.addEventListener('click', e => {
        const rm = e.target.closest('[data-remove]');
        if (rm) {
            e.stopPropagation();
            const id = rm.dataset.remove;
            const arr = getHidden();
            if (!arr.includes(id)) { arr.push(id); setHidden(arr); }
            if (current && current.userId === id) {
                current = null;
                renderHead();
                msgs.innerHTML = '<div class="empty">还没有打开任何对话</div>';
            }
            renderPeers();
            return;
        }

        const row = e.target.closest('[data-peer]');
        if (row) {
            const p = getPeers().find(x => x.userId === row.dataset.peer);
            openChat(row.dataset.peer, p ? p.name : '');
        }
    });

    if (groupsBox) {
        groupsBox.addEventListener('click', e => {
            const row = e.target.closest('[data-group]');
            if (row) openGroupChat(row.dataset.group, row.dataset.gname);
        });
    }

    // ---------- 建群逻辑 ----------
    const btnCreateGroup = document.getElementById('btn-create-group');
    if (btnCreateGroup) {
        btnCreateGroup.onclick = function (e) {
            e.preventDefault();
            const modal = document.getElementById('group-modal');
            if (modal) {
                modal.style.display = 'flex';
                document.getElementById('new-group-name').value = '';
                document.getElementById('new-group-members').value = '';
            }
        };
    }

    const btnCancelGroup = document.getElementById('cancel-group');
    if (btnCancelGroup) {
        btnCancelGroup.onclick = function (e) {
            e.preventDefault();
            const modal = document.getElementById('group-modal');
            if (modal) modal.style.display = 'none';
        };
    }

    const btnSubmitGroup = document.getElementById('submit-group');
    if (btnSubmitGroup) {
        btnSubmitGroup.onclick = async function (e) {
            e.preventDefault();
            const groupName = document.getElementById('new-group-name').value.trim();
            const membersStr = document.getElementById('new-group-members').value.trim();

            if (!groupName) {
                return YT.toast('请输入群名称');
            }

            btnSubmitGroup.disabled = true;
            btnSubmitGroup.textContent = '创建中...';

            try {
                const r = await YT.api.post('/api/private_message/establish/group', {
                    groupName: groupName,
                    ownerId: me.userId
                });

                if (r.success && r.data && r.data.groupId) {
                    const newGroupId = r.data.groupId;

                    if (membersStr) {
                        const memberIds = membersStr.split(',').map(s => s.trim()).filter(s => s);
                        for (const uid of memberIds) {
                            try {
                                const addRes = await YT.api.post('/api/private_message/add/member', {
                                    groupId: newGroupId,
                                    userId: uid,
                                    fromUser: me.userId
                                });
                                if (!addRes.success) {
                                    alert("拉 " + uid + " 失败: " + (addRes.message || "未知错误"));
                                } else {
                                    console.log("拉人成功: " + uid);
                                }
                            } catch (err) {
                                alert("网络错误，拉 " + uid + " 失败");
                            }
                        }
                    }

                    YT.toast('群聊创建成功！');
                    document.getElementById('group-modal').style.display = 'none';

                    await syncMyGroups();
                    openGroupChat(newGroupId, groupName);
                } else {
                    YT.toast(r.message || '创建群聊失败');
                }
            } catch (err) {
                YT.toast('请求失败：' + err.message);
            } finally {
                btnSubmitGroup.disabled = false;
                btnSubmitGroup.textContent = '创建';
            }
        };
    }

    renderPeers();
    renderMyGroups();

    (async () => {
        await Promise.all([loadInbox(), refreshUnread(), syncMyGroups()]);
        schedulePoll();
    })();
})();
```

## @Kitaajya

现在只是提醒你进群了，但是前端显示不到群啊

## Copilot

是的，这个现象说明“前端提示走了，但左侧群列表没拿到真实数据”。这通常不是渲染问题，而是 2 种情况之一：

1. 后端没把你插进 `group_member`
2. 前端本地缓存 `yt_my_groups_xxx` / `yt_my_group_ids_xxx` 还停留在旧值，导致 UI 不刷新

你现在的现象很典型：toast 代码在本地执行了，但 `renderMyGroups()` 读到的还是旧数据，所以页面上看不到群。

最直接判断方法：

1. 先在浏览器控制台里清缓存
```javascript
const me = JSON.parse(localStorage.getItem('yt_user') || '{}');
const uid = me.userId;
localStorage.removeItem('yt_my_groups_' + uid);
localStorage.removeItem('yt_my_group_ids_' + uid);
location.reload();
```

2. 然后手动请求后端真实群列表
```javascript
fetch('/api/private_message/select/my/groups?me=你的用户ID')
  .then(r => r.json())
  .then(console.log)
```

如果返回是空数组，说明后端根本没插成功；如果返回有群，说明前端缓存/状态没刷新。

关键点：
- 你现在的 toast 是“本地 diff 触发的”
- 它不等于“服务端真的返回了新群”
- 也就是说，前端显示不到群，最可能是 `syncMyGroups()` 里拿到的 `r.data` 仍然是空，或者本地缓存没清掉

另外，你之前这段代码里有个很关键的问题：

```javascript
.catch(() => {});
```

这会吞掉所有失败，导致你完全不知道“拉人接口失败了”。  
所以你现在看不到群，很可能就是拉人接口失败了，但前端没有报错。

建议改成这样，方便调试：

```javascript
const addRes = await YT.api.post('/api/private_message/add/member', {
    groupId: newGroupId,
    userId: uid,
    fromUser: me.userId
});

console.log('add member result:', addRes);
if (!addRes.success) {
    alert("拉 " + uid + " 失败: " + (addRes.message || "未知错误"));
}
```

然后再看后端返回什么。

你这个场景最靠谱的修复顺序是：

- 先保证后端插入真正成功
- 再清掉前端缓存
- 再刷新页面
- 再看群列表是否渲染

你现在的前端看不到群，说明本地缓存层和服务端数据层不一致。  
这个问题不是 HTML 结构有问题，而是“缓存/接口失败/吞异常”三者叠加导致的。

如果你愿意，我可以下一步直接给你一版“最强调试版 message.js”，它会在控制台打印：
- 当前用户
- 真实群列表返回值
- 本地缓存 old/new groupId
- 拉人接口返回值

这样你直接打开页面就能看到到底是“后端没插进去”还是“前端没刷新”。
