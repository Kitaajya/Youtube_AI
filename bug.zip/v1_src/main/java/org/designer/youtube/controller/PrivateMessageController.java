@PostMapping("/add/member")
public Result<Map<String, Object>> addGroupMember(@RequestParam String groupId, @RequestParam String userId,@RequestParam String fromUser) {
    return privateMessageService.addGroupMember(groupId, userId,fromUser);
}