await YT.api.post('/api/private_message/add/member', {
    groupId: newGroupId,
    userId: uid
}).catch(() => {});